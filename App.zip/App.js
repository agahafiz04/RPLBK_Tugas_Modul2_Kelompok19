import React, { useState, useEffect } from 'react';


function App() {
  const [quote, setQuote] = useState("");
  const [author, setAuthor] = useState("");
  const [tags, setTags] = useState("");

  useEffect(() => {
    fetch("http://api.quotable.io/random")
    .then(res => res.json())
    .then(
      (quote) => {
        setQuote(quote.content);
        setAuthor(quote.author);
        setTags(quote.tags);
        console.log(quote);
      }
    )
  },[]);

  let fetchNewQuote = () => {
    fetch("http://api.quotable.io/random")
    .then(res => res.json())
    .then(
      (quote) => {
        setQuote(quote.content);
        setAuthor(quote.author);
        setTags(quote.tags);
        console.log(quote);
      }
    )
  }

  return (
    <div className="App">
      <main>
          <div>
          <div className="title">
            <h2>Quotes</h2>
            <div className="underline"></div>
            <div></div>
          </div>
          <article className="review">
            <h5>{quote}</h5> 
            <h6>-{author}-</h6> <br/>
            <h7>#{tags}</h7> <br/>

            <button className="random-btn" onClick={fetchNewQuote}>
              Generate Random Quote
            </button>
          </article>
          </div>
          <br/>
        </section>
      </main>
    </div>
  );
}

export default App;
